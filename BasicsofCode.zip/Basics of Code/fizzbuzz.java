/* Ah, the good old fizzbuzz problem.
By Ursula Sarracini
*/

public class fizzbuzz{
	public static void main(String args[]){
		
		int[] numbers = new int[100];
		
		for(int i = 0; i < numbers.length; i++){
			numbers[i] = i+1;
		}
		String fizz = "fizz";
		String buzz = "buzz";
		String fizzbuzz = "fizzbuzz";
		
		for(int i = 0; i < numbers.length; i++){
			if (numbers[i] % 15 == 0){
				System.out.println(fizzbuzz + " at " + numbers[i]);
			}
			else if (numbers[i] % 3 == 0){
				System.out.println(buzz + " at " + numbers[i]);
			}
			else if (numbers[i] % 5 == 0){
				System.out.println(fizz + " at " + numbers[i]);
			}
			else{
				System.out.println(numbers[i]);
			}
		}
		
	}
}
		
				
