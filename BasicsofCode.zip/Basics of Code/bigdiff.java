/* Finds the range of an array (difference between largest and smallest number in the array)
By Ursula Sarracini
*/

public class bigdiff{
	public static void main(String args[]){
		int[] numbers = {10, 11, 14, 5, 2, 4, 1, 7, 9};
		BigDifference(numbers);
	
	}
		
		public static int BigDifference(int[] nums) {
		int max = nums[0];
		int min = nums[0];
		int currMax = 0;
		int currMin = 0;
		int diff = 0;
		
		 for (int i = 0; i < nums.length; i++){
			 currMax = nums[i];
			 currMin = nums[i];
			 if (currMax > max){
			 	 max = currMax;
			 	 System.out.println("max so far: " + max);
			 }
			 if (currMin < min){
			 	min = currMin;
			 	System.out.println("min so far: " + min);
			 }
		 }
		 System.out.println("Overall max: " + max + " and Overall min: " + min);
		 diff = max - min;
		 System.out.println("difference "+ diff);
		 return diff;
		}
}

	
