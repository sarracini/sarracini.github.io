/* Determines if the array has a point where it can split so that the sum
of the first half equals the sum of the second half. This runs in O(n^2) time.
Try finding a way to optimize it to O(n) time. Hint: Use two arrays, one for 
your numbers, and one which holds the current accumulated sum as you increment i.
By Ursula Sarracini
*/

public class canbalance{

	public static void main(String args[]){
		int[] nums = {1, 2, 3, 1, 0, 2, 3};
		boolean canbalance = canBalance(nums);
		System.out.println(canbalance);
	}
	
	public static boolean canBalance(int[] nums) {
		boolean canbalance = false;
		int sumfirsthalf = 0;
		int sumsecondhalf = 0;
		for (int i = 0; i < nums.length; i++){
			sumfirsthalf += nums[i];
			
			for (int j = i+1; j < nums.length; j++){
				sumsecondhalf += nums[j];
			}
			System.out.println("i= " + i + " first sum: " + sumfirsthalf);
			System.out.println("i= " + i + " second sum: " + sumsecondhalf);
			if (sumfirsthalf == sumsecondhalf){
				canbalance = true;
				System.out.println("We have a match at " + i + "!!!!!");
			}
			sumsecondhalf = 0;			
		}		
		return canbalance;
	}


}





