/* Slightly altered version of fizzarray.java. This time create an array
between two numbers, but also do fizzbuzz for that array!
By Ursula Sarracini
*/

public class fizzarray2{
	public static void main(String args[]){
		int start = 1;
		int end = 17;
		String[] fizzy = fizzBuzz(start, end);
		for (int i = 0; i < fizzy.length; i++){
		System.out.println(fizzy[i]);
		}
	
	}
	public static String[] fizzBuzz(int start, int end) {
		int size = end - start; 
		int[] org = new int[size];
		String[] arr = new String[size];
		String fizz = "fizz";
		String buzz = "buzz";
		String fizzbuzz = fizz+buzz;
		for (int i = 0; i < org.length; i++){
			org[i] = start+i;
			if (org[i] % 15 == 0){
				arr[i] = fizzbuzz;
			}
			else if (org[i] % 3 == 0){
				arr[i] = fizz;			
			}
			else if (org[i] % 5 == 0){
				arr[i] = buzz;	
			}
			else{
				arr[i] = String.valueOf(org[i]);
			}
		  }
		  return arr;
	}
}

	
