/* Finds the factorial of a number recursively
Doesn't handle negative or really large numbers
By Ursula Sarracini
*/

public class factorial{
	public static void main(String args[]){
	long num = 5;
	System.out.println(Factorial(num));
	
	}
		
		public static long Factorial(long n) {
			long m;
			if (n == 1)
				return n;
			else{
				m = Factorial(n-1) * n;
			}
			return m;
		}
		
}

	
