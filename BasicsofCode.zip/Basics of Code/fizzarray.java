/* Creates an array between two two numbers
By Ursula Sarracini
*/

public class fizzarray{
	public static void main(String args[]){
		int start = 17;
		int end = 25;
		int[] fizzy = fizzArray(start, end);
		for (int i = 0; i < fizzy.length; i++){
		System.out.println(fizzy[i]);
		}
	
	}
		public static int[] fizzArray(int start, int end) {
			int size = end - start; 
			int[] arr = new int[size];
		  
			for (int i = 0; i < arr.length; i++){
				arr[i] = start+i;
			}
			return arr;
		}	
}

	
