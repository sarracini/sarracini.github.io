/* Finds the combination of two (relatively small) numbers
By Ursula Sarracini
*/
import java.math.*;
import java.util.Scanner;


public class choose{
	public static void main(String args[]){
//	int top = -10;
//	int bottom = 3;
	Scanner in = new Scanner(System.in);
	System.out.println("Enter a number: ");
	int top = in.nextInt();
	System.out.println("Enter another number: ");
	int bottom = in.nextInt();
	System.out.println(Math.abs(top) + "C" + Math.abs(bottom) + " = " + 
		Choose(Math.abs(top), Math.abs(bottom)));
	
	}
		
		public static int Factorial(int n) {
			int m;
				if (n == 1)
					return n;
				else{
					m = Factorial(n-1) * n;
				}
				return m;
		}

		public static int Choose(int top, int bottom){
			int topRes = 1;
			int bottomRes = 1; 
			int result = 0;
			int diff = top - bottom;

			if (top > bottom){
				topRes = Factorial(top);
				bottomRes = Factorial(bottom);
				diff = Factorial(diff);
			}

			result = topRes/ (bottomRes*diff);
			return result;

		}
}

	
